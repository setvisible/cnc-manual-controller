Copy the file K8055D.DLL from the folder \DLL_v5.0.0.0 to the \Windows\System32 folder.
In 64-bit environment copy the file to \Windows\SysWOW64 folder.

Microsoft Visual Studio .NET users please note: The K8055D.DLL is a standard Windows DLL, you cannot reference it !

